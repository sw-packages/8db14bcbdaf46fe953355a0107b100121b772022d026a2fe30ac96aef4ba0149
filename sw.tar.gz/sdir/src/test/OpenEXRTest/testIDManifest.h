// SPDX-License-Identifier: BSD-3-Clause
// Copyright (c) Contributors to the OpenEXR Project.

#ifndef _TEST_ID_MANIFEST_
#define _TEST_ID_MANIFEST_

#include <string>

void testIDManifest(const std::string &tempDir);

#endif
