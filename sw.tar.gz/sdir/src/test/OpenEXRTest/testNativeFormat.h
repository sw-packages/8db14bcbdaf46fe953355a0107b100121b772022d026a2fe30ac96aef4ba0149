//
// SPDX-License-Identifier: BSD-3-Clause
// Copyright (c) Contributors to the OpenEXR Project.
//


#include <string>

void testNativeFormat (const std::string &tempDir);

